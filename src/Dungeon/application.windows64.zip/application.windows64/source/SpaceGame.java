import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SpaceGame extends PApplet {

// Space Game | December 2020 \\
// By Zoey Ng | Computer Programming 1 \\


SoundFile laser, explosion;
Spaceship ship;
ArrayList<Laser> lasers;
ArrayList<Asteroid> asteroids;
ArrayList<Star> stars;
ArrayList<Enemy> enemies;
ArrayList<EnemyLaser> elasers;
ArrayList<PowerUp> pUps;
Timer asteroidTimer, enemyTimer, puTimer;
int score, pass, weaponCount, laserCount, enemyHealth;
boolean play;

public void setup() {
  
  laser = new SoundFile(this, "laser.wav");
  explosion = new SoundFile(this, "explosion.wav");
  ship = new Spaceship();
  lasers = new ArrayList();
  elasers = new ArrayList();
  asteroids = new ArrayList();
  stars = new ArrayList();
  enemies = new ArrayList();
  pUps = new ArrayList();
  asteroidTimer = new Timer(PApplet.parseInt(random(500, 1000)));
  asteroidTimer.start();
  puTimer = new Timer(7000);
  puTimer.start();
  enemyTimer = new Timer(7000);
  enemyTimer.start();
  score = 0;
  weaponCount = 1;
  laserCount = 0;
  enemyHealth = 100;
  pass = 0;
  play = false;
}

public void draw() {
  noCursor();

  //Gameplay
  if (!play) {
    startScreen();
  } else {
    background(9, 10, 26);

    //Create Stars
    stars.add(new Star(PApplet.parseInt(random (width)), 0));
    for (int i = 0; i < stars.size(); i++) {
      Star star = stars.get(i);
      star.display();
      star.move();
      if (star.reachedBottom()) {
        stars.remove(star);
      }
    }

    //Timer for Asteroids
    if (asteroidTimer.isFinished()) {
      asteroids.add(new Asteroid(PApplet.parseInt(random(width)), -25));
      asteroidTimer.start();
    }
    // Distribution of Asteroids
    for (int i = 0; i < asteroids.size(); i++) {
      Asteroid asteroid = asteroids.get(i);
      asteroid.display();
      asteroid.move();
      //collision between spaceship and asteroids
      if (ship.asteroidIntersection(asteroid)) {
        asteroids.remove(asteroid);
        ship.health -= asteroid.health;
        score-=50;
      }
      if (asteroid.reachedBottom()) {
        pass++;
        asteroids.remove(asteroid);
      }
    }

    // Enemy ships that fire
    if (enemyTimer.isFinished()) {
      enemies.add(new Enemy(0, 100, PApplet.parseInt(random(500, 1500)), enemyHealth));
      enemyTimer.start();
    }

    // enemy ship render
    for (int i = 0; i<enemies.size(); i++) {
      Enemy enemy = enemies.get(i);
      enemy.move();
      enemy.display();
      // enemy and ship intersection
      if (ship.shipIntersect(enemy)) {
        ship.health-=enemy.healthStart;
        score+=enemy.healthStart;
        enemies.remove(enemy);
      }
      if (enemy.isFinished()) {
        elasers.add(new EnemyLaser(enemy.x, enemy.y));
        enemy.start();
      }
    }

    // enemy laser rendering
    for (int i = elasers.size()-1; i>=0; i--) {
      EnemyLaser elaser = (EnemyLaser) elasers.get(i);
      elaser.fire();
      elaser.display();
      // Enemy Laser vs. Ship
      if (ship.enemyLaserIntersect(elaser)) {
        ship.health-=elaser.power;
        elasers.remove(elaser);
      }
      if (elaser.reachedBottom()) {
        elasers.remove(elaser);
      }
    }

    //Lasers
    for (int i = 0; i < lasers.size(); i++) {
      Laser laser = lasers.get(i);
      laser.display();
      laser.shoot();
      //collision between asteroids and lasers
      for (int j = 0; j < asteroids.size(); j++) {
        Asteroid asteroid = asteroids.get(j);
        if (asteroid.laserIntersection(laser)) {
          lasers.remove(laser);
          asteroid.health -= laser.damage;
          if (asteroid.health < 1) {
            explosion.play();
            asteroids.remove(asteroid);
            score += 100;
          }
        }
      }
      if (laser.reachedTop()) {
        lasers.remove(laser);
      }
    }

    // PowerUp Distribution
    if (puTimer.isFinished()) {
      pUps.add(new PowerUp(PApplet.parseInt(random(width)), -20));
      puTimer.start();
    }
    // PowerUp rendering and collision detection
    for (int i = 0; i<pUps.size(); i++) {
      PowerUp pu = pUps.get(i);
      pu.move();
      pu.display();
      // PowerUp and ship intersection
      if (ship.puIntersect(pu)) {
        // Apply PowerUp Effects
        if (pu.pu == 0) { // Adds damage
          ship.health+=100;
        } else if (pu.pu == 1) { //Adds health
          ship.health+=500;
        } else if (pu.pu == 2) { //Adds lasers
          weaponCount++;
        } 
        pUps.remove(pu);
      }
      // dispose of rocks at bottom
      if (pu.reachedBottom()) {
        pUps.remove(pu);
      }
    }

    //Spaceship
    ship.display(mouseX, mouseY);

    infoPanel();

    //GameOver Logic
    if (ship.health<1 || pass>10) {
      play = false;
      gameOver();
    }
  }
}

public void mousePressed() {
  if (play) {
    laser.play();
  }
  if (weaponCount == 1) {
    lasers.add(new Laser(ship.x, ship.y));
    laserCount++;
  } else if (weaponCount == 2) {
    lasers.add(new Laser(ship.x, ship.y));
    lasers.add(new Laser(ship.x+72, ship.y));
    lasers.add(new Laser(ship.x-72, ship.y));
  }
}

public void startScreen() {
  background(0);
  textAlign(CENTER);
  background(9, 10, 26);

  //Create Stars
  stars.add(new Star(PApplet.parseInt(random (width)), 0));
  for (int i = 0; i < stars.size(); i++) {
    Star star = stars.get(i);
    star.display();
    star.move();
    if (star.reachedBottom()) {
      stars.remove(star);
    }
  }

  textSize(50);
  text("Start", width/2, height/2);
  text("Press Anywhere to Continue", width/2, height/2+75);

  if (mousePressed) {
    play = true;
  }
}

public void infoPanel() {
  fill(128, 128);
  rectMode(CORNER);
  rect(0, height-100, width, height-100);
  fill(255, 128);
  textSize(50);
  textAlign(LEFT);
  text("Score:" + score, 0, height-35);
  textAlign(CENTER);
  text("Health:" + ship.health, width/2, height-35);
  textAlign(RIGHT);
  text("Asteroids Passed:" + pass, width, height-35);
  if (pass >10) {
    fill(255, 0, 0);
  }
}

public void gameOver() {
  background(9, 10, 26);
  textAlign(CENTER);
  textSize(200);
  text("GAME OVER!", width/2, height/2);
  textSize(100);
  text("Final Score:" + score, width/2, height/2+100);

  //Create Stars
  stars.add(new Star(PApplet.parseInt(random (width)), 0));
  for (int i = 0; i < stars.size(); i++) {
    Star star = stars.get(i);
    star.display();
    star.move();
    if (star.reachedBottom()) {
      stars.remove(star);
    }
  }

  noLoop();
}
class Asteroid {
  //member variables
  int x, y, health, speed, radius, random;
  char displayMode;
  int c;
  PImage asteroid1, asteroid2, asteroid3, asteroid4, asteroid5;

  //contstructor
  Asteroid(int x, int y) {
    this.x = x;
    this.y = y;
    health = PApplet.parseInt(random(50-100));
    speed = PApplet.parseInt(random(5, 7));
    radius = 25;
    displayMode = '1';
    c = 255;
    random = PApplet.parseInt(random(1, 5));
    asteroid1 = loadImage("asteroid1.png");
    asteroid2 = loadImage("asteroid2.png");
    asteroid3 = loadImage("asteroid3.png");
    asteroid4 = loadImage("asteroid4.png");
    asteroid5 = loadImage("asteroid5.png");
  }

  //member methods
  public void move() {
    y+=speed;
  }

  //collision for asteroids and lasers
  public boolean laserIntersection(Laser laser) {
    float distance = dist(x, y, laser.x, laser.y);
    if (distance < radius + laser.radius) {
      return true;
    } else {
      return false;
    }
  }

  public boolean reachedBottom() {
    if (y > height) {
      return true;
    } else {
      return false;
    }
  }

  public void display() {
    if (random==5) {
      image(asteroid5, x, y);
    } else if (random==4) {
      image(asteroid4, x, y);
    } else if (random==3) {
      image(asteroid3, x, y);
    } else if (random==2) {
      image(asteroid2, x, y);
    } else {
      image(asteroid1, x, y);
    }
  }
}
class Enemy {
  //member variables
  int r, radius, health, x, y, speed, healthStart, random1, random2;
  boolean right;
  int savedTime; 
  int totalTime;
  PImage enemy1, enemy2;

  //contructor
  Enemy(int x, int y, int t, int health) {
    healthStart = health;
    r = 25;
    radius = 25;
    this.x = x;
    this.y = y;
    this.health = health;
    speed = 5;
    this.totalTime = t;
    random1 = PApplet.parseInt(random(1, 100));
    random2 = PApplet.parseInt(random(1, 100));
    enemy1 = loadImage("enemy1.png");
    enemy2 = loadImage("enemy2.png");
  }
  //member methods
  public void display() {
    imageMode(CENTER);

    if (random1 > random2) {
      image(enemy1, x, y);
    } else {
      image(enemy2, x, y);
    }
  }

  public void move() {
    x += speed;
    if (x >= width|| x <= 0) {
      speed *= -1;
      y+=50;
    }
  }
  public boolean laserIntersect(Laser laser) {
    // Calculate distance
    float distance = dist(x, y, laser.x, laser.y);
    if (distance < r + laser.radius) { 
      return true;
    } else {
      return false;
    }
  }

  public void start() {
    savedTime = millis();
  }


  public boolean isFinished() { 
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
class EnemyLaser {
  int r, x, y, speed, power; 
  int c;

  EnemyLaser(int x, int y) {
    r = 4; 
    power = PApplet.parseInt(random(10, 100));
    this.x = x; 
    this.y = y; 
    speed = PApplet.parseInt(random(5, 22));    
    c = 0xffff0000;
  }

  public void fire() {
    y += speed;
  }

  public boolean reachedBottom() {
    if (y > height) { 
      return true;
    } else {
      return false;
    }
  }

  public void display() {
    fill(c);
    noStroke();
    rect(x, y, 5, 20, 2);
  }
}
class Laser {
  //member variables
  int x, y, speed, radius, damage;
  int c;

  //contstructor
  Laser(int x, int y) {
    this.x = x;
    this.y = y;
    speed = PApplet.parseInt(random(10,20));
    c = 0xff007DFF;
    radius = 4;
    damage = PApplet.parseInt(random(10, 50));
  }

  //member methods
  public void shoot() {
    y-=speed;
  }

  public boolean reachedTop() {
    if (y < -5) {
      return true;
    } else {
      return false;
    }
  }

  public void display() {
    fill(c);
    noStroke();
    rectMode(CENTER);
    rect(x, y, 5, 20, 2);
  }
}
class PowerUp {
  //member variables
  int x, y, speed, radius, pu;
  int c;
  PImage damagepowerup, healthpowerup, laserpowerup;

  //contstructor
  PowerUp(int x, int y) {
    this.x = x;
    this.y = y;
    speed = PApplet.parseInt(random(1, 5));
    radius = 25;
    pu = PApplet.parseInt(random(3));
    damagepowerup = loadImage("damagepowerup.png");
    healthpowerup = loadImage("healthpowerup.png");
    laserpowerup = loadImage("laserpowerup.png");
  }

  //member methods
  public void move() {
    y+=speed;
  }

  public boolean reachedBottom() {
    if (y > height) {
      return true;
    } else {
      return false;
    }
  }

  public void display() {
    switch(pu) {
    case 0: //damage
      image(damagepowerup, x, y);
      break;
    case 1: //life
      image(healthpowerup, x, y);
      break;
    case 2: //laser
      image(laserpowerup, x, y);
      break;
    }
  }
}
class Spaceship {
  //member variables
  int r, x, y, health, lives, radius;
  PImage spaceship;

  //contructor
  Spaceship() {
    r = 25;
    x = 0;
    y = 0;
    health = 1000;
    lives = 3;
    radius = 25;
    spaceship = loadImage("spaceship.png");
  }

  //member methods
  public void display(int x, int y) {
    this.x = x;
    this.y = y;
    imageMode(CENTER);
    image(spaceship, x, y);
  }

  public boolean enemyLaserIntersect(EnemyLaser elaser) {
    // Calculate distance
    float distance = dist(x, y, elaser.x, elaser.y); 

    // Compare distance to radius
    if (distance < r + elaser.r) { 
      return true;
    } else {
      return false;
    }
  }

  //collision for asteroids and spaceship
  public boolean asteroidIntersection(Asteroid asteroid) {
    float distance = dist(x, y, asteroid.x, asteroid.y);
    if (distance < radius + asteroid.radius) {
      return true;
    } else {
      return false;
    }
  }

  public boolean puIntersect(PowerUp pu) {
    // Calculate distance
    float distance = dist(x, y, pu.x, pu.y);
    if (distance < r + pu.radius) { 
      return true;
    } else {
      return false;
    }
  }

  public boolean shipIntersect(Enemy enemy) {
    // Calculate distance
    float distance = dist(x, y, enemy.x, enemy.y); 

    // Compare distance to radius
    if (distance < r + enemy.r) { 
      return true;
    } else {
      return false;
    }
  }
}
class Star {
  //member variables
  int x, y, speed, diameter;
  int c;

  //contstructor
  Star(int x, int y) {
    this.x = x;
    this.y = y;
    speed = PApplet.parseInt(random(1, 10));
    diameter = PApplet.parseInt(random(1,4));
    c = PApplet.parseInt(random (190,255));
  }
  
  //member methods
  public void move() {
    y+=speed;
  }

  public boolean reachedBottom() {
    if (y > height) {
      return true;
    } else {
      return false;
    }
  }
  
  public void display() {
    fill(c);
    noStroke();
    ellipse (x, y, diameter, diameter);
  }
}
// Example 10-5: Object-oriented timer
// by Daniel Shiffon

class Timer {
  int savedTime; // When Timer started
  int totalTime; // How long Timer should last

  Timer(int tempTotalTime) {
    totalTime = tempTotalTime;
  }

  // Starting the timer
  public void start() {
    // When the timer starts it stores the current time in milliseconds.
    savedTime = millis();
  }

  // The function isFinished() returns true if 5,000 ms have passed. 
  // The work of the timer is farmed out to this method.
  public boolean isFinished() { 
    // Check how much time has passed
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
  public void settings() {  size(displayWidth, displayHeight); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SpaceGame" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
