import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SpaceGame extends PApplet {

// Space Game | December 2020 \\
// By Zoey Ng | Computer Programming 1 \\


SoundFile laser, boom;

Spaceship ship;
ArrayList<Laser> lasers;
ArrayList<Asteroid> asteroids;
ArrayList<Star> stars;
Timer timer;
int score, pass;
boolean play;

public void setup() {
  laser = new SoundFile(this, "Narn-FighterGun.wav");
  
  ship = new Spaceship(0xff9AABBC);
  lasers = new ArrayList();
  asteroids = new ArrayList();
  stars = new ArrayList();
  timer = new Timer(PApplet.parseInt(random(500, 3000)));
  timer.start();
  score = 0;
  pass = 0;
  play = false;
}

public void draw() {
  noCursor();

  //Gameplay
  if (!play) {
    startScreen();
  } else {
    background(9, 10, 26);

    //Create Stars
    stars.add(new Star(PApplet.parseInt(random (width)), 0));
    for (int i = 0; i < stars.size(); i++) {
      Star star = stars.get(i);
      star.display();
      star.move();
      if (star.reachedBottom()) {
        stars.remove(star);
      }
    }

    //Timer for Asteroids
    if (timer.isFinished()) {
      asteroids.add(new Asteroid(PApplet.parseInt(random(width)), -25));
      timer.start();
    }
    // Distribution of Asteroids
    for (int i = 0; i < asteroids.size(); i++) {
      Asteroid asteroid = asteroids.get(i);
      asteroid.display();
      asteroid.move();
      //collision between spaceship and asteroids
      if (ship.asteroidIntersection(asteroid)) {
        asteroids.remove(asteroid);
        ship.health -= asteroid.health;
        score+=50;
      }
      if (asteroid.reachedBottom()) {
        pass++;
        asteroids.remove(asteroid);
      }
    }

    //Lasers
    for (int i = 0; i < lasers.size(); i++) {
      Laser laser = lasers.get(i);
      laser.display();
      laser.shoot();
      //collision between asteroids and lasers
      for (int j = 0; j < asteroids.size(); j++) {
        Asteroid asteroid = asteroids.get(j);
        if (asteroid.laserIntersection(laser)) {
          lasers.remove(laser);
          asteroid.health -= laser.damage;
          if (asteroid.health < 1) {
            asteroids.remove(asteroid);
            score += asteroid.health;
          }
        }
      }
      if (laser.reachedTop()) {
        lasers.remove(laser);
      }
    }

    //Spaceship
    ship.display(mouseX, mouseY);

    infoPanel();

    //GameOver Logic
    if (ship.health<1 || pass>5) {
      play = false;
      gameOver();
    }
  }
}

public void mousePressed() {
  if (play) {
    laser.play();
  }
  lasers.add(new Laser(ship.x, ship.y));
  lasers.add(new Laser(ship.x+35, ship.y));
  lasers.add(new Laser(ship.x-35, ship.y));
}

public void startScreen() {
  background(0);
  textAlign(CENTER);
  background(9, 10, 26);

  //Create Stars
  stars.add(new Star(PApplet.parseInt(random (width)), 0));
  for (int i = 0; i < stars.size(); i++) {
    Star star = stars.get(i);
    star.display();
    star.move();
    if (star.reachedBottom()) {
      stars.remove(star);
    }
  }

  text("Start", width/2, height/2);
  text("How To Play", width/2, height/2+20);

  if (mousePressed) {
    play = true;
  }
}

public void infoPanel() {
  fill(128, 128);
  rectMode(CORNER);
  rect(0, height-50, width, height-50);
  fill(255, 128);
  text("Health:" + ship.health, 20, height-20);
  //text("Lives:" + ship.lives, 100, height-20);
  //text("Level:" + ship.lives, 180, height-20);
  text("Score:" + score, 260, height-20);
  if (pass >7) {
    fill(255, 0, 0);
  }
  text("Pass:", + pass, 340, height -20);
}

public void gameOver() {
  background(0);
  textAlign(CENTER);
  background(9, 10, 26);

  //Create Stars
  stars.add(new Star(PApplet.parseInt(random (width)), 0));
  for (int i = 0; i < stars.size(); i++) {
    Star star = stars.get(i);
    star.display();
    star.move();
    if (star.reachedBottom()) {
      stars.remove(star);
    }
  }

  text("GAME OVER!", width/2, height/2);
  text("Final Score", + score, width/2, height/2+20);

  noLoop();
}
class Asteroid {
  //member variables
  int x, y, health, speed, radius;
  char displayMode;
  int c;
  PImage asteroid1, asteroid2;

  //contstructor
  Asteroid(int x, int y) {
    this.x = x;
    this.y = y;
    health = 50;
    speed = PApplet.parseInt(random(1, 5));
    radius = 25;
    displayMode = '1';
    c = 255;
    asteroid1 = loadImage("asteroid1.png");
  }

  //member methods
  public void move() {
    y+=speed;
  }

  //collision for asteroids and lasers
  public boolean laserIntersection(Laser laser) {
    float distance = dist(x, y, laser.x, laser.y);
    if (distance < radius + laser.radius) {
      return true;
    } else {
      return false;
    }
  }

  public boolean reachedBottom() {
    if (y > height) {
      return true;
    } else {
      return false;
    }
  }

  public void display() {
    fill(c);
    noStroke();
    //ellipse (x, y, diameter, diameter);
    image(asteroid1, x, y);
  }
}
class Enemy {
  //member variables
  int x, y, health;
  char displayMode;
  int c1;

  //contructor
  Enemy(int c1) {
    x = 0;
    y = 0;
    health = 50;
    displayMode = '1';
    this.c1 = c1;
  }
  
  //member methods
  public void display(int x, int y) {
    if (displayMode == '1') {
      //TO DO: create enemy graphic
    }
  }
}
class Laser {
  //member variables
  int x, y, speed, radius, damage;
  int c;

  //contstructor
  Laser(int x, int y) {
    this.x = x;
    this.y = y;
    speed = 10;
    c = 0xff007DFF;
    radius = 4;
    damage = PApplet.parseInt(random(10, 50));
  }

  //member methods
  public void shoot() {
    y-=speed;
  }

  public boolean reachedTop() {
    if (y < -5) {
      return true;
    } else {
      return false;
    }
  }

  public void display() {
    fill(c);
    noStroke();
    rectMode(CENTER);
    rect(x, y, 5, 20, 2);
  }
}
class PowerUp {
  //member variables
  int x, y, speed, radius, pu;
  char displayMode;
  int c;
  PImage asteroid1, asteroid2;

  //contstructor
  PowerUp(int x, int y) {
    this.x = x;
    this.y = y;
    speed = PApplet.parseInt(random(1, 5));
    radius = 25;
    displayMode = '1';
    pu = PApplet.parseInt(random(0-4));
    asteroid1 = loadImage("asteroid1.png");
  }

  //member methods
  public void move() {
    y+=speed;
  }

  //collision for asteroids and lasers
  public boolean laserIntersection(Laser laser) {
    float distance = dist(x, y, laser.x, laser.y);
    if (distance < radius + laser.radius) {
      return true;
    } else {
      return false;
    }
  }

  public boolean reachedBottom() {
    if (y > height) {
      return true;
    } else {
      return false;
    }
  }

  public void display() {
    fill(c);
    noStroke();
    //ellipse (x, y, diameter, diameter);
    image(asteroid1, x, y);
  }
}
class Spaceship {
  //member variables
  int x, y, health, lives, radius;
  char displayMode;
  int c1;

  //contructor
  Spaceship(int c1) {
    x = 0;
    y = 0;
    health = 100;
    lives = 3;
    radius = 25;
    displayMode = '1';
    this.c1 = c1;
  }

  //collision for asteroids and spaceship
  public boolean asteroidIntersection(Asteroid asteroid) {
    float distance = dist(x, y, asteroid.x, asteroid.y);
    if (distance < radius + asteroid.radius) {
      return true;
    } else {
      return false;
    }
  }

  //member methods
  public void display(int x, int y) {
    this.x = x;
    this.y = y;
    if (displayMode == '1') {
      rectMode(CENTER);
      stroke(9, 10, 26);
      //thruster of ship
      fill(154, 171, 188);
      rect(x+18, y+10, 15, 15);
      rect(x-18, y+10, 15, 15);
      //turret of ship
      stroke(183, 207, 232);
      strokeWeight(5);
      line(x+35, y-5, x+35, y+1);
      line(x-35, y-5, x-35, y+1);
      //wings of ship
      stroke(9, 10, 26);
      strokeWeight(1);
      triangle(x, y-20, x+40, y+12, x-40, y+12);
      //base of ship
      ellipse(x, y, 15, 80);
      //head of ship
      triangle(x, y-50, x+7, y-18, x-7, y-18);
    }
  }
}
class Star {
  //member variables
  int x, y, speed, diameter;
  int c;

  //contstructor
  Star(int x, int y) {
    this.x = x;
    this.y = y;
    speed = PApplet.parseInt(random(1, 10));
    diameter = PApplet.parseInt(random(1,4));
    c = PApplet.parseInt(random (190,255));
  }
  
  //member methods
  public void move() {
    y+=speed;
  }

  public boolean reachedBottom() {
    if (y > height) {
      return true;
    } else {
      return false;
    }
  }
  
  public void display() {
    fill(c);
    noStroke();
    ellipse (x, y, diameter, diameter);
  }
}
// Example 10-5: Object-oriented timer
// by Daniel Shiffon

class Timer {
  int savedTime; // When Timer started
  int totalTime; // How long Timer should last

  Timer(int tempTotalTime) {
    totalTime = tempTotalTime;
  }

  // Starting the timer
  public void start() {
    // When the timer starts it stores the current time in milliseconds.
    savedTime = millis();
  }

  // The function isFinished() returns true if 5,000 ms have passed. 
  // The work of the timer is farmed out to this method.
  public boolean isFinished() { 
    // Check how much time has passed
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
  public void settings() {  size(400, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SpaceGame" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
