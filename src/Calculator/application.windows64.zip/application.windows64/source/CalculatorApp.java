import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class CalculatorApp extends PApplet {

/*
 Calculator App - Programming I
 Zoey Ng | November 2020
 */

//Global Variables
Button[] numButtons = new Button[10];
Button[] optButtons = new Button[15];

//Declare Global Variables
String dVal, op;
boolean left;
float l, r, result;

public void setup() {
  

  //Initialize Global Variables
  dVal = "0";
  op = "";
  left = true;
  l = 0.0f;
  r = 0.0f;
  result = 0.0f;

  //numButtons
  numButtons[0] = new Button(80, 500, width/5, height/6, "0", 0xff1C1C1C, 0xff383838);
  numButtons[1] = new Button(80, 400, width/5, height/6, "1", 0xff1C1C1C, 0xff383838);
  numButtons[2] = new Button(160, 400, width/5, height/6, "2", 0xff1C1C1C, 0xff383838);
  numButtons[3] = new Button(240, 400, width/5, height/6, "3", 0xff1C1C1C, 0xff383838);
  numButtons[4] = new Button(80, 300, width/5, height/6, "4", 0xff1C1C1C, 0xff383838);
  numButtons[5] = new Button(160, 300, width/5, height/6, "5", 0xff1C1C1C, 0xff383838);
  numButtons[6] = new Button(240, 300, width/5, height/6, "6", 0xff1C1C1C, 0xff383838);
  numButtons[7] = new Button(80, 200, width/5, height/6, "7", 0xff1C1C1C, 0xff383838);
  numButtons[8] = new Button(160, 200, width/5, height/6, "8", 0xff1C1C1C, 0xff383838);
  numButtons[9] = new Button(240, 200, width/5, height/6, "9", 0xff1C1C1C, 0xff383838);
  //optButtons
  optButtons[0] = new Button(0, 500, width/5, height/6, "π", 0xff1C1C1C, 0xff383838);
  optButtons[1] = new Button(160, 500, width/5, height/6, ".", 0xff1C1C1C, 0xff383838);
  optButtons[2] = new Button(240, 500, width/5, height/6, "±", 0xff1C1C1C, 0xff383838);
  optButtons[3] = new Button(320, 500, width/5, height/6, "=", 0xff1C1C1C, 0xff383838);
  optButtons[4] = new Button(0, 400, width/5, height/6, "|x|", 0xff1C1C1C, 0xff383838);
  optButtons[5] = new Button(320, 400, width/5, height/6, "+", 0xff1C1C1C, 0xff383838);
  optButtons[6] = new Button(0, 300, width/5, height/6, "x²", 0xff1C1C1C, 0xff383838);
  optButtons[7] = new Button(320, 300, width/5, height/6, "-", 0xff1C1C1C, 0xff383838);
  optButtons[8] = new Button(0, 200, width/5, height/6, "√", 0xff1C1C1C, 0xff383838);
  optButtons[9] = new Button(320, 200, width/5, height/6, "x", 0xff1C1C1C, 0xff383838);
  optButtons[10] = new Button(0, 100, width/5, height/6, "AC", 0xff1C1C1C, 0xff383838);
  optButtons[11] = new Button(80, 100, width/5, height/6, "Info", 0xff1C1C1C, 0xff383838);
  optButtons[12] = new Button(160, 100, width/5, height/6, "Rand", 0xff1C1C1C, 0xff383838);
  optButtons[13] = new Button(240, 100, width/5, height/6, "%", 0xff1C1C1C, 0xff383838);
  optButtons[14] = new Button(320, 100, width/5, height/6, "÷", 0xff1C1C1C, 0xff383838);
}

public void draw() {
  background(28, 28, 28);

  //Show Calculator Display
  updateDisplay();

  //Display and Hover Buttons
  for (int i = 0; i<numButtons.length; i++) {
    numButtons[i].hover();
    numButtons[i].display();
  }
  for (int i = 0; i<optButtons.length; i++) {
    optButtons[i].hover();
    optButtons[i].display();
  }
}

public void updateDisplay() {
  fill(56, 56, 56);
  rect(0, 0, 400, 100);

  fill(255);
  textAlign(RIGHT);

  //Render Scaling Text
  if (dVal.length()<12) {
    textSize(50);
  } else if (dVal.length()<13) {
    textSize(48);
  } else if (dVal.length()<14) {
    textSize(46);
  } else if (dVal.length()<15) {
    textSize(42);
  } else {
    textSize(39);
  }
  text(dVal, 390, 90);
}

public void mouseReleased() {
  for (int i = 0; i < numButtons.length; i++) {
    if (numButtons[i].hover && dVal.length() < 15) {
      handleEvent(numButtons[i].val, true);
    }
  }
  for (int i = 0; i < optButtons.length; i++) {
    if (optButtons[i].hover) {
      handleEvent(optButtons[i].val, false);
    }
  }
  println("");
  println("L: " + l + " R: " + r + " Op: " + op);
  println("Result: " + result + " dVal: " + dVal + " Left: " + left);
}

public void keyPressed() {
  println("KEY:" + key + " keyCode:" + keyCode);

  if (key == '0') {
    handleEvent("0", true);
  } else if (key == '1') {
    handleEvent("1", true);
  } else if (key == '2') {
    handleEvent("2", true);
  } else if (key == '3') {
    handleEvent("3", true);
  } else if (key == '4') {
    handleEvent("4", true);
  } else if (key == '5') {
    handleEvent("5", true);
  } else if (key == '6') {
    handleEvent("6", true);
  } else if (key == '7') {
    handleEvent("7", true);
  } else if (key == '8') {
    handleEvent("8", true);
  } else if (key == '9') {
    handleEvent("9", true);
  } else if (key == '+') {
    handleEvent("+", false);
  } else if (key == '-') {
    handleEvent("-", false);
  } else if (key == '*') {
    handleEvent("x", false);
  } else if (key == '/') {
    handleEvent("÷", false);
  } else if (key == '.') {
    handleEvent(".", false);
  } else if (key == 8) {
    handleEvent("AC", false);
  } else if (key == 10) { //(key == CODED) {
    if (key == ENTER || key == RETURN) {
      handleEvent("=", false);
    }
  }
  println("");
  println("L: " + l + " R: " + r + " Op: " + op);
  println("Result: " + result + " dVal: " + dVal + " Left: " + left);
}

public String handleEvent(String val, boolean num) {
  if (left && num && dVal.length()<15) {
    if (dVal.equals("0") || result == l) {
      dVal = (val);
      l = PApplet.parseFloat(dVal);
    } else { 
      dVal += (val);
      l = PApplet.parseFloat(dVal);
    }
  } else if (!left && num) {
    if (dVal.equals("0") || result == l) {
      dVal = (val);
      r = PApplet.parseFloat(dVal);
    } else { 
      dVal += (val);
      r = PApplet.parseFloat(dVal);
    }
  } else if (val.equals("AC")) {
    dVal = "0";
    result = 0.0f;
    left = true;
    r = 0.0f;
    l = 0.0f;
    op = "";
  } else if (val.equals("+")) {
    if (!left) {
      performCalculation();
    } else {
      op = "+";
      left = false;
      dVal = "0";
    }
  } else if (val.equals("-")) {
    op = "-";
    left = false;
    dVal = "0";
  } else if (val.equals("x")) {
    op = "x";
    left = false;
    dVal = "0";
  } else if (val.equals("÷")) {
    op = "÷";
    left = false;
    dVal = "0";
  } else if (val.equals("±")) {
    if (left) {
      l *= -1;
      dVal = str(l);
    } else {
      r *= -1;
      dVal = str(r);
    }
  } else if (val.equals("Rand")) {
    if (left) {
      l = random(0, 1);
      dVal = str(l);
    } else {
      r = random(0, 1);
      dVal = str(r);
    }
  } else if (val.equals("%")) {
    if (left) {
      l *= 0.1f;
      dVal = str(l);
    } else {
      r *= 0.1f;
      dVal = str(r);
    }
  } else if (val.equals("√")) {
    if (left) {
      l = sqrt(l);
      dVal = str(l);
    } else {
      r = sqrt(r);
      dVal = str(r);
    }
  } else if (val.equals("x²")) {
    if (left) {
      l = sq(l);
      dVal = str(l);
    } else {
      r = sq(r);
      dVal = str(r);
    }
  } else if (val.equals("|x|")) {
    if (left && dVal.contains("-")) {
      l = l * -1;
      dVal = str(l);
    } else if (!left && dVal.contains("-")) {
      r = r * -1;
      dVal = str(r);
    }
  } else if (val.equals("π")) {
    if (left) {
      l = PI * l;
      dVal = str(l);
    } else {
      r = PI * r;
      dVal = str(r);
    }
  } else if (val.equals(".") && !dVal.contains(".")) {
    dVal += (val);
  } else if (val.equals("=")) {
    performCalculation();
  } else if (val.equals("Info")) {
    dVal = ("Created By: Zoey Ng");
  }
  return val;
}

public void performCalculation() {
  if (op.equals("+")) {
    result = l + r;
  } else if (op.equals("-")) {
    result = l - r;
  } else if (op.equals("x")) {
    result = l * r;
  } else if (op.equals("÷")) {
    result = l / r;
  }
  l = result;
  dVal = str(result);
  left = true;
}
class Button {
  // Member Variables (Memory Reservation)
  int x, y, w, h;
  int c1, c2;
  String val;
  boolean hover;

  //Contructor
  Button(int x, int y, int w, int h, String val, int c1, int c2) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.val = val;
    this.c1 = c1;
    this.c2 = c2;
  }

  //Display Method
  public void display () {
    if (hover) {
      fill(c2);
    } else {
      fill(c1);
    }
    strokeWeight(2);
    stroke(84, 84, 84);
    rect(x, y, w, h);
    textSize(30);
    textAlign(CENTER);
    fill(255);
    text(val, x+w/2, y+h/2);
  }

  //Mouse Interaction Method
  public void hover () {
    hover = mouseX > x && mouseX< x+w && mouseY > y && mouseY < y+h;
  }
}
  public void settings() {  size(400, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "CalculatorApp" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
